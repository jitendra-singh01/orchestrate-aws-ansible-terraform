Sites Available
---------------

Define host definitions here.
It'd be a good thing if you keep your hosts indexed by domain name, eg:

```
example.com (handles traffic from both www.example.com and example.com)
foobar.com (as above)
test.foobar.com (handles traffic from both www.test.foobar.com and test.foobar.com)
```

