[Nginx Server Configs homepage](https://github.com/h5bp/server-configs-nginx)
 | [Documentation table of contents](TOC.md)

# Sites available

Files in this folder are not referenced/loaded automatically. The intended
purpose of this folder is to contain all server config files whether they
are currently in use or not.

So, for example this folder may contain:

	example.com
	example.com-original
	otherdomain.com
	newproject.com

Where each file contains the server block(s) specific to that project.
